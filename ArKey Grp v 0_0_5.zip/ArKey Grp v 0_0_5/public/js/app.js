document.addEventListener("DOMContentLoaded", () => {
  // Verifica si estamos en la página de login, dashboard o inventarios
  if (window.location.pathname === "/") {
    document.body.classList.add("login-page");
    handleLoginPage();
  } else if (window.location.pathname.includes("dashboard.html")) {
    document.body.classList.add("dashboard-page");
    handleDashboardPage();
  } else if (window.location.pathname.includes("inventarios.html")) {
    document.body.classList.add("inventarios-page");
    handleInventariosPage();
  }
  loadBackgroundSettings(); // Cargar configuración de fondo al inicio
});

// Función para manejar la página de login
function handleLoginPage() {
  const loginForm = document.getElementById("login-form");
  const errorMessage = document.getElementById("error-message");

  loginForm.addEventListener("submit", async (e) => {
    e.preventDefault();

    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    try {
      const response = await fetch("http://localhost:2000/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = await response.json();
      if (response.ok) {
        localStorage.setItem("token", data.token);
        window.location.href = "/dashboard.html"; // Redirigir al dashboard
      } else {
        errorMessage.textContent = data.message || "Error desconocido";
      }
    } catch (error) {
      console.error(error);
      errorMessage.textContent = "Error al conectar con el servidor";
    }
  });

  loadBackgroundSettings();
}

// Función para manejar la página del dashboard
async function handleDashboardPage() {
  const token = localStorage.getItem("token");
  if (!token) {
    window.location.href = "/"; // Redirigir al login si no hay token
    return;
  }

  const logoutButton = document.getElementById("logout-button");
  const moduleList = document.getElementById("module-list");

  // Obtener el role_id desde el servidor
  const userData = await getUserData(token);
  const roleId = userData.role_id; // El role_id viene desde el backend

  // Definir los módulos según el role_id
  const modules = {
    1: ["Contabilidad", "Recursos Humanos", "Inventarios"],  // Admin
    2: ["Contabilidad"], // Usuario de contabilidad
    3: ["Recursos Humanos"], // Usuario de recursos humanos
    4: ["Inventarios"], // Usuario de inventarios
  };

// Mostrar los módulos como elementos de lista <li>
modules[roleId]?.forEach((module) => {
  const li = document.createElement("li"); // Crear un elemento <li>
  li.textContent = module;
  li.classList.add("module-item");

  // Redirección dinámica al hacer clic
  li.addEventListener("click", () => {
    const moduleFile = module.replace(/\s+/g, '') + ".html"; // "Recursos Humanos" → "RecursosHumanos.html"
    window.location.href = moduleFile;
  });

  moduleList.appendChild(li);
});

  // Configuración del gráfico
  setupChart();

  // Cerrar sesión
  logoutButton.addEventListener("click", () => {
    localStorage.removeItem("token");
    window.location.href = "/"; // Redirigir al login
  });

  // Configurar el menú desplegable de configuración
  configureSettingsMenu();
}

// Función para obtener los datos del usuario desde el servidor
async function getUserData(token) {
  try {
    const response = await fetch("http://localhost:2000/api/auth/me", {
      method: "GET",
      headers: { "Authorization": `Bearer ${token}` },
    });
    const data = await response.json();
    if (response.ok) {
      return data; // Debería contener el role_id
    } else {
      throw new Error("No se pudo obtener los datos del usuario");
    }
  } catch (error) {
    console.error(error);
    window.location.href = "/"; // Redirigir al login si hay error
  }
}

// Función para manejar lo que sucede cuando un módulo es clickeado
function handleModuleClick(module) {
  alert(`Has clickeado en el módulo: ${module}`);
  // Puedes redirigir a diferentes páginas o ejecutar acciones aquí
}

// Función para configurar el gráfico
function setupChart() {
  const ctx = document.getElementById("myChart").getContext("2d");
  new Chart(ctx, {
    type: "bar",
    data: {
      labels: ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio"],
      datasets: [{
        label: "Usuarios activos",
        data: [12, 19, 3, 5, 2, 3],
        backgroundColor: "#00ffff",
        borderColor: "#00ffff",
        borderWidth: 1,
      }],
    },
    options: {
      scales: {
        y: { beginAtZero: true },
      },
    },
  });
}

// Función para cargar configuración guardada
function loadBackgroundSettings() {
  const loginBackground = localStorage.getItem("loginBackground") || "login.jpg";
  const dashboardBackground = localStorage.getItem("dashboardBackground") || "inicio.jpg";
  const inventoryBackground = localStorage.getItem("inventoryBackground") || "inicio_alt1.jpg";  // Fondo predeterminado para inventarios

  // Aplicar fondo del login si estamos en la página de login
  if (window.location.pathname === "/") {
    document.body.style.backgroundImage = `url("/images/${loginBackground}")`;
  }

  // Aplicar fondo del dashboard si estamos en la página del dashboard
  if (window.location.pathname.includes("dashboard.html")) {
    document.body.style.backgroundImage = `url("/images/${dashboardBackground}")`;
  }

  // Aplicar fondo de inventarios si estamos en la página de inventarios
  if (window.location.pathname.includes("inventarios.html")) {
    document.body.style.backgroundImage = `url("/images/${inventoryBackground}")`;
  }
}

// Configurar el menú desplegable de configuración
function configureSettingsMenu() {
  const settingsButton = document.getElementById("settings-button");
  const settingsDropdown = document.getElementById("settings-dropdown");

  settingsButton.addEventListener("click", () => {
    settingsDropdown.style.display =
      settingsDropdown.style.display === "block" ? "none" : "block";
    settingsButton.classList.toggle("active");
  });

  document.addEventListener("click", (e) => {
    if (
      !settingsButton.contains(e.target) &&
      !settingsDropdown.contains(e.target)
    ) {
      settingsDropdown.style.display = "none";
      settingsButton.classList.remove("active");
    }
  });

  // Configurar miniaturas para el fondo del login
  setupBackgroundPreviews(
    "login-background-preview",
    "loginBackground",
    ["login.jpg", "login_alt1.jpg", "login_alt2.jpg", "login_alt3.png", "login_alt4.jpg", "login_alt5.jpg", "login_alt6.jpg", "login_alt7.png"]
  );

  // Configurar miniaturas para el fondo del dashboard
  setupBackgroundPreviews(
    "dashboard-background-preview",
    "dashboardBackground",
    ["inicio.jpg", "inicio_alt1.jpg", "inicio_alt2.jpg", "inicio_alt3.png", "inicio_alt4.jpg", "inicio_alt5.jpg", "inicio_alt6.jpg", "inicio_alt7.png"]
  );

  // Configurar miniaturas para el fondo de la página de inventarios
  setupBackgroundPreviews(
    "inventory-background-preview",
    "inventoryBackground",
    ["inicio_alt1.jpg", "inicio_alt2.jpg", "inicio_alt3.png", "inicio_alt4.jpg", "inicio_alt5.jpg", "inicio_alt6.jpg", "inicio_alt7.png"]
  );
}

// Función para configurar las miniaturas
function setupBackgroundPreviews(containerId, localStorageKey, imageOptions) {
  const container = document.getElementById(containerId);
  const currentBackground = localStorage.getItem(localStorageKey) || imageOptions[0];

  // Limpiar el contenedor antes de agregar miniaturas
  container.innerHTML = "";

  // Crear una miniatura para cada opción
  imageOptions.forEach((image) => {
    const img = document.createElement("img");
    img.src = `/images/${image}`;
    img.alt = image;
    img.dataset.value = image;

    // Marcar la imagen seleccionada actualmente
    if (image === currentBackground) {
      img.classList.add("selected");
    }

    // Agregar evento de clic para seleccionar la imagen
    img.addEventListener("click", () => {
      // Actualizar el estado en localStorage
      localStorage.setItem(localStorageKey, image);

      // Remover la clase 'selected' de todas las miniaturas
      container.querySelectorAll("img").forEach((img) => img.classList.remove("selected"));

      // Marcar la miniatura seleccionada
      img.classList.add("selected");

      // Si es el fondo del inventarios, aplicarlo inmediatamente
      if (localStorageKey === "inventoryBackground") {
        document.body.style.backgroundImage = `url("/images/${image}")`;
      }
    });

    container.appendChild(img);
  });
}

// Cargar configuraciones y configurar el menú al cargar el DOM
window.addEventListener('DOMContentLoaded', (event) => {
  loadBackgroundSettings();
  configureSettingsMenu();
});

// Agregar listener para pageshow (útil al retroceder en el navegador)
window.addEventListener("pageshow", (event) => {
  loadBackgroundSettings();
});