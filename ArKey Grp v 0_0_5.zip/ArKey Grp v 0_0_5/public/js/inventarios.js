document.addEventListener("DOMContentLoaded", () => {
    const token = localStorage.getItem("token");
  
    if (!token) {
      alert("Debes iniciar sesión primero.");
      window.location.href = "/"; // redirige al login
      return;
    }
  
    // Referencias al formulario y contenedor
    const form = document.getElementById("form-producto");
    const contenedorProductos = document.getElementById("contenedor-productos");
  
    // Mostrar productos al cargar
    obtenerProductos(token);
  
    // Evento de envío del formulario
    form.addEventListener("submit", (e) => {
      e.preventDefault();
  
      const nombre = form.nombre.value;
      const cantidad = form.cantidad.value;
      const marca = form.marca.value;
      const imagen = form.imagen.files[0];
  
      const formData = new FormData();
      formData.append("nombre", nombre);
      formData.append("cantidad", cantidad);
      formData.append("marca", marca);
      if (imagen) formData.append("imagen", imagen);
  
      fetch("/api/productos", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body: formData,
      })
        .then((res) => res.json())
        .then((data) => {
          alert(data.message);
          form.reset();
          obtenerProductos(token);
        })
        .catch((err) => {
          console.error("Error al guardar producto:", err);
          alert("Error al guardar producto.");
        });
    });
  
    // Función para obtener productos y mostrarlos
    function obtenerProductos(token) {
      fetch("/api/productos", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
        .then((res) => res.json())
        .then((productos) => {
          const tbody = document.querySelector("#tabla-productos tbody");
          tbody.innerHTML = "";
    
          productos.forEach((producto, index) => {
            const tr = document.createElement("tr");
    
            tr.innerHTML = `
              <td>${producto.nombre}</td>
              <td>${producto.marca}</td>
              <td>${producto.cantidad}</td>
              <td>
                ${
                  producto.imagen_url
                    ? `<button data-index="${index}" class="btn-ver-imagen">Ver imagen</button>
                       <div id="imagen-${index}" style="display:none; margin-top:5px;">
                         <img src="${producto.imagen_url}" alt="Imagen de ${producto.nombre}" style="max-width:150px; max-height:150px;">
                       </div>`
                    : "Sin imagen"
                }
              </td>
            `;
    
            tbody.appendChild(tr);
          });
    
          // Delegación de eventos para botones
          document.querySelectorAll(".btn-ver-imagen").forEach((btn) => {
            btn.addEventListener("click", () => {
              const index = btn.getAttribute("data-index");
              const divImg = document.getElementById(`imagen-${index}`);
              divImg.style.display = divImg.style.display === "none" ? "block" : "none";
            });
          });
        })
        .catch((err) => {
          console.error("Error al obtener productos:", err);
          alert("Error al cargar productos.");
        });
    }    
  });
  